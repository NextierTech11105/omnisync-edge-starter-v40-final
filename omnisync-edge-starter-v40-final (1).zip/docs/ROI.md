# ROI Calculator (Baseline)

**Inputs**
- Price per message: $0.01
- Your markup: $0.05
- Monthly messages per client: 50,000
- Clients: N

**Per-client monthly gross margin**
`(markup - cost) * volume = ($0.05 - $0.01) * 50,000 = $2,000`

**Annualized**
`$2,000 * 12 = $24,000` per client

**40 clients => $960,000/yr`

Adjust by replacing variables above.
