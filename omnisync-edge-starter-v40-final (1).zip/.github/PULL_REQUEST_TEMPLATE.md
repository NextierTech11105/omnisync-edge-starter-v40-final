## What & Why
-

## How to test
-

## Checklist
- [ ] Tests passing (`npm test`)
- [ ] No secrets leaked (`gitleaks` green)
- [ ] Docs updated if needed
